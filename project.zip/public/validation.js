// const myForm = document.getElementById("formCreation");

// myForm.addEventListener("submit", event => {

// });

//to display message

let attribute = $(".modalClass").attr("data-toggle");

attribute = attribute.includes("modal");
if(attribute){
 
  $('.modalClass').trigger('click');
  $(".modalClass").attr("data-toggle","");
}


//for calling delete routes  
$(".deleteAdmin").click(function () {

  let url = `http://localhost:3000/adminDelete/${this.id}`;

  $.ajax({                              //https://stackoverflow.com/questions/32963736/how-to-make-ajax-get-post-request-in-express-server
    method: 'DELETE',
    url: url,
    success: function (data) {
      // console.log(data);
    }
  });


});




//for enabling edit pop-up

$(".editAdmin").click(function () {
  console.log(this.id);
  let idTitle = "title-" + this.id;
  let idDesc = "desc-" + this.id;
  let idLoc = "loc-" + this.id;
  let idDate = "date-" + this.id;
  let idTime = "time-" + this.id;
  let idAge = "age-" + this.id;
  let idSex = "sex-" + this.id;
  let idSeats = "seats-" + this.id;

  var title = document.getElementById(idTitle).innerHTML;
  $("#popup-event-name").val(title);

  var desc = document.getElementById(idDesc).innerHTML;
  $("#popup-event-des").val(desc);

  var loc = document.getElementById(idLoc).innerHTML;
  loc = loc.replace("|","").trim();
  $("#popup-event-loc").val(loc);

  var date = document.getElementById(idDate).innerHTML;
  date = date.replace("|","").trim();
  $("#popup-event-date").val(date);

  var time = document.getElementById(idTime).innerHTML;
  time = time.replace("|","").trim();
  $("#popup-event-time").val(time);

  var age = document.getElementById(idAge).innerHTML;

  if (age.includes("Above")) {
    
    $("#popup-event-above18").prop("checked", true);
  }
  else {
    $("#popup-event-noRestrict").prop("checked", true);
    
  }


  var sex = document.getElementById(idSex).innerHTML;
  if (sex == "Male Event") {
    $("#popup-event-male").prop("checked", true);
  }
  else if (sex == "Female Event") {
    $("#popup-event-female").prop("checked", true);
  }
  else {
    $("#popup-event-bothGender").prop("checked", true);
  }
  // $("#popup-event-name").val(title);

  var seats = document.getElementById(idSeats).innerHTML;
  seats = seats.replace("Seats |","").trim();
  $("#popup-event-seats").val(seats);



  // $(".popup-event-name").val("title-"+this.title);

  // let url = `http://localhost:3000/getDetail/${this.id}`;

  // $.ajax({                              
  //    method: 'GET',
  //   url: url,
  //   success: function (data) {
  //     console.log(data);
  //   }
  // });


});

$('#editAdmin').on('show.bs.modal', function (event) {
  debugger;
  var button = $(event.relatedTarget) // Button that triggered the modal
  var recipient = button.data('whatever') // Extract info from data-* attributes
  // If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
  // Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
  var modal = $(this)
  modal.find('.modal-title').text('New message to ' + recipient)
  modal.find('.modal-body input').val(recipient)
})

