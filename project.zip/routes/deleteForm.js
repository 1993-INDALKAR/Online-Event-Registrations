const express = require("express");
const data = require("../data");
const formInfoRoutes = require("./formInfo");
const router = express.Router();

router.delete("/:id", async (req, res) => {

    // console.log(req.params.id);

    let del = await data.deleteForm(req.params.id);

    // console.log(del);

    let message = {};

    console.log(del);

    if (del) {

        message.title = "Success";
        message.description = "Successfully Deleted Form."

        // let forms = await data.getAllForms();
        // console.log("forms");
        // res.redirect(req.originalUrl);
        // res.sendStatus(200).redirect("/admin");
        // res.status(200).render('admin', { title: 'Admin Page-Form Info', formInfoActive: "",show:true, createFormActive: "active" });
        res.status(200).render("admin", { Message: message, title: 'Admin Page', createFormActive: "active", show: true, formInfoActive: "", modal: "modal" });
    }
    else {

        message.title = "Error";
        message.description = "Sorry could not delete form."

        res.status(400).render("admin", { Message: message, title: 'Admin Page', createFormActive: "active", show: true, formInfoActive: "", modal: "modal" });
    }



    // console.log(del);

    // res.json(del);


});


module.exports = router; 