const express = require("express");
const data = require("../data");
const router = express.Router();


router.post("/:id", async (req, res) => {

    // console.log(req.params.id);

    let form = req.body;
    let formId= req.params.id;

    if(form.age == "option1"){
        form.age = true;
    }
    else{
        form.age = false;
    }

    if(form.gender == "option1"){
        form.gender = "M";
    }
    else if(form.age == "option2"){
        form.gender = "F";
    }
    else{
        form.gender = "MF";
    }

    let edit = await data.replaceForm(formId,form);

    let message = {};

    if(edit.hasOwnProperty("message")){

        
        message.title = "Error";
        message.description = "Sorry could not update form."

        //error occured
        res.status(403).render("admin",{Message:message,title:'Admin Page',createFormActive:"active",show:true,formInfoActive:"",modal:"modal"});
    }
    else{

        message.title = "Success";
        message.description = "Successfully Updated Form."

        res.status(200).render("admin",{modal:"modal",Message:message,title:'Admin Page',createFormActive:"active",show:true,formInfoActive:""});
   
    }

    // if()

    // let del = await data.deleteForm(req.params.id);

    // console.log(edit);

    // let edit;
    // if (edit) {

    //     let forms = await data.getAllForms();
    //     res.render('admin', { title: 'Admin Page-Form Info', form: forms, formInfoActive: "active", createFormActive: "" });

    // }



    


});


module.exports = router;