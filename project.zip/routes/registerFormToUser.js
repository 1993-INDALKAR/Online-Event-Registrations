const express = require("express");
const data = require("../data");
const router = express.Router();


router.post("/:id",async(req,res)=>{

    // console.log(req.body);

    // console.log(req.params.id);

    let formData = req.body;

    let formId = req.params.id;

    // console.log(req.cookies);

    let cookie = req.cookies.name;

    let userId;

    if(cookie){

        if(cookie.includes("user")){

            userId = cookie.replace("user","");

            formData.userId = userId.toString();
    
   
            let registerUserToForm =await  data.registerForm(formData,formId);
        
           
            if(! registerUserToForm.message){

                let message = "success";

                res.redirect('/user?message=' + message);

                // res.redirect("/user");
            }
            else{
                // res.redirect("/user");

                let message = "failure";

                res.redirect('/user?message=' + message);
            }
       }
       else{

        res.status(403).render("wrongAccess");
   
       }
   
   
      

    }
    else{
        res.status(403).render("notLogged");
    }

   

   




});

module.exports = router;